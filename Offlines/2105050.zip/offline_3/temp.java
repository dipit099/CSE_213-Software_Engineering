
// import java.util.ArrayList;
// import java.util.List;

// class Movie {
// private String movieName;
// private String genre;

// Movie(String movieName) {
// this.movieName = movieName;
// }

// public String getMovieName() {
// return movieName;
// }

// public String getGenre() {
// return genre;
// }

// public void setGenre(String genre) {
// this.genre = genre;
// }
// }

// interface Observer {
// String getUserName();

// void addFavGenre(Subject genre);

// void removeFavGenre(Subject genre);

// void notifyUser(Movie movie) throws InterruptedException;

// List<String> getGenreList();

// }

// class User implements Observer {
// private String userName;
// private List<String> genreList;

// public User(String name) {
// this.userName = name;
// this.genreList = new ArrayList<>();
// }

// public String getUserName() {
// return userName;
// }

// @Override
// public void addFavGenre(Subject genre) {
// this.genreList.add(genre.getName());
// genre.addObserver(this);
// }

// @Override
// public void removeFavGenre(Subject genre) {
// this.genreList.remove(genre.getName());
// genre.removeObserver(this);
// }

// @Override
// public void notifyUser(Movie movie) throws InterruptedException {
// Thread.sleep(1500);
// System.out
// .println("[Hello " + this.userName + "] ------ New Movie Release : " +
// movie.getMovieName() + " ("
// + movie.getGenre() + ")");

// }

// @Override
// public List<String> getGenreList() {
// return genreList;
// }

// }

// interface Subject {
// String getName();

// void addObserver(Observer observer);

// void removeObserver(Observer observer);

// void notifyObservers(Movie movie) throws InterruptedException;

// void addMovie(Movie movie) throws InterruptedException;

// void viewMovieList();

// void viewUserList();
// }

// class Genre implements Subject {
// private String genreName;
// private List<Observer> observerList;
// private List<Movie> movieList;

// Genre(String genreName) {
// this.genreName = genreName;
// observerList = new ArrayList<>();
// movieList = new ArrayList<>();
// // System.out.println("Created Genre: " + genreName);
// }

// @Override
// public String getName() {
// return genreName;
// }

// @Override
// public void addObserver(Observer observer) {
// observerList.add(observer);

// }

// @Override
// public void removeObserver(Observer observer) {
// observerList.remove(observer);
// }

// @Override
// public void addMovie(Movie movie) throws InterruptedException {
// movie.setGenre(genreName);

// Thread thread = new Thread(() -> {
// try {
// notifyObservers(movie);
// } catch (InterruptedException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// });
// thread.start();
// System.out.println();
// System.out.println("Uploading New Movie: " + movie.getMovieName() + " (" +
// movie.getGenre()
// + ") to the server >>>>>>>>>>>>");
// for (int i = 0; i <= 100; i = i + 20) {
// System.out.println("Progress - " + i + "% out of 100%");
// }
// movieList.add(movie);
// // System.out.println();
// System.out.println(
// "Movie: " + movie.getMovieName() + " Uploaded Successfully <<<<<<<<<<<<");
// System.out.println();
// Thread.sleep(3000);

// }

// @Override
// public void notifyObservers(Movie movie) throws InterruptedException {
// // System.out.println("Notifying Observers");
// // System.out.println("size ------------------------- " +
// observerList.size());
// for (Observer observer : observerList) {
// // System.out.println("Notifying " + observer);
// observer.notifyUser(movie);
// }

// }

// @Override
// public void viewMovieList() {
// System.out.println("Printing Movie List of Genre: " + genreName);

// for (Movie movie : movieList) {
// System.out.println("Movie Name: " + movie.getMovieName() + " Genre: " +
// movie.getGenre());
// }
// System.out.println("Done");
// }

// @Override
// public void viewUserList() {
// System.out.println("Printing User List of Genre: " + genreName);
// for (Observer observer : observerList) {
// System.out.println("User Name: " + observer.getUserName());
// }
// System.out.println("Done");
// }
// }

// public class DesiFlix {
// public static void main(String[] args) throws InterruptedException {

// Subject comedyGenre = new Genre("Comedy");
// Subject thrillerGenre = new Genre("Thriller");
// Subject horrorGenre = new Genre("Horror");

// Observer user1 = new User("Raihan");
// user1.addFavGenre(thrillerGenre);
// user1.addFavGenre(horrorGenre);
// user1.addFavGenre(comedyGenre);

// Observer user2 = new User("Wahdi");
// user2.addFavGenre(thrillerGenre);
// user2.addFavGenre(comedyGenre);
// user2.addFavGenre(horrorGenre);

// Observer user3 = new User("Mehedi");
// user3.addFavGenre(horrorGenre);
// user3.addFavGenre(thrillerGenre);

// Observer user4 = new User("Tahmid");
// user4.addFavGenre(thrillerGenre);
// user4.addFavGenre(comedyGenre);

// Observer user5 = new User("Ruwad");
// user5.addFavGenre(horrorGenre);
// user5.addFavGenre(thrillerGenre);

// // thrillerGenre.viewUserList();

// // thrillerGenre.viewMovieList();

// // user5.removeFavGenre(thrillerGenre); // Ruwad removed thriller genre
// // user5.addFavGenre(comedyGenre); // Ruwad added comedy genre
// // thrillerGenre.viewUserList();

// thrillerGenre.addMovie(new Movie("Joker"));
// comedyGenre.addMovie(new Movie("Friends"));
// horrorGenre.addMovie(new Movie("The Nun"));
// thrillerGenre.addMovie(new Movie("The Dark Knight"));
// comedyGenre.addMovie(new Movie("The Office"));
// horrorGenre.addMovie(new Movie("The Ring"));

// }
// }

// package Offlines.offline_3;

// public class NotificationExample {
// public static void sendNotification(String message) {
// for (int userId = 0; userId < 4; userId++) {
// System.out.println();
// System.out.println(userId);
// System.out.println("Connecting to the notification server...");
// System.out.println("Connected to the server.");
// System.out.println("Processing notification data...");
// System.out.println("Sending notification to " + ": " + message);
// System.out.println("Notification sent successfully to " + userId);
// }
// }

// public static void main(String[] args) {
// System.out.println("Main task started...");

// // Creating and starting a new thread for sending the notification
// Thread notificationThread = new Thread(() -> {
// sendNotification("Your order has been confirmed!");
// });

// notificationThread.start(); // Start the thread for sending the notification

// System.out.println("Main task continues without waiting for the notification
// to be sent...");
// for (int i = 0; i < 10; i++) {
// System.out.println("Main task - Value: " + i);

// }
// }

// }
