import java.util.List;

interface Observer {
    String getUserName();

    void addFavGenre(Subject genre);

    void removeFavGenre(Subject genre);

    void notifyUser(Movie movie) throws InterruptedException;

    List<String> getGenreList();

}
