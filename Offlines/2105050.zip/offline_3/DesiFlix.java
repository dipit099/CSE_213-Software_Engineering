
public class DesiFlix {
    public static void main(String[] args) throws InterruptedException {

        Subject comedyGenre = new Genre("Comedy");
        Subject thrillerGenre = new Genre("Thriller");
        Subject horrorGenre = new Genre("Horror");

        Observer user1 = new User("Raihan");
        user1.addFavGenre(thrillerGenre);
        user1.addFavGenre(horrorGenre);
        user1.addFavGenre(comedyGenre);

        Observer user2 = new User("Wahdi");
        user2.addFavGenre(thrillerGenre);
        user2.addFavGenre(comedyGenre);
        user2.addFavGenre(horrorGenre);

        Observer user3 = new User("Mehedi");
        user3.addFavGenre(horrorGenre);
        user3.addFavGenre(thrillerGenre);

        Observer user4 = new User("Tahmid");
        user4.addFavGenre(thrillerGenre);
        user4.addFavGenre(comedyGenre);

        Observer user5 = new User("Ruwad");
        user5.addFavGenre(horrorGenre);
        user5.addFavGenre(thrillerGenre);

        // thrillerGenre.viewUserList();

        // thrillerGenre.viewMovieList();
        // thrillerGenre.viewUserList();

        thrillerGenre.addMovie(new Movie("Joker"));
        comedyGenre.addMovie(new Movie("Friends"));
        horrorGenre.addMovie(new Movie("The Nun"));

        // user5.removeFavGenre(thrillerGenre); // Ruwad removed thriller genre
        // thrillerGenre.viewUserList();
        // user5.addFavGenre(comedyGenre); // Ruwad added comedy genre

        thrillerGenre.addMovie(new Movie("The Dark Knight"));
        horrorGenre.addMovie(new Movie("The Ring"));
        comedyGenre.addMovie(new Movie("The Office"));

    }
}