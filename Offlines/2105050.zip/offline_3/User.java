import java.util.ArrayList;
import java.util.List;

class User implements Observer {
    private String userName;
    private List<String> genreList;

    public User(String name) {
        this.userName = name;
        this.genreList = new ArrayList<>();
    }

    public String getUserName() {
        return userName;
    }

    @Override
    public void addFavGenre(Subject genre) {
        this.genreList.add(genre.getName());
        genre.addObserver(this);
    }

    @Override
    public void removeFavGenre(Subject genre) {
        this.genreList.remove(genre.getName());
        genre.removeObserver(this);
    }

    @Override
    public void notifyUser(Movie movie) throws InterruptedException {
        Thread.sleep(1500);
        System.out
                .println("[Hello " + this.userName + "] ------ New Movie Release : " + movie.getMovieName() + " ("
                        + movie.getGenre() + ")");

    }

    @Override
    public List<String> getGenreList() {
        return genreList;
    }

}
