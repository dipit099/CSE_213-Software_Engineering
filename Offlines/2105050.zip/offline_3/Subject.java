
interface Subject {
    String getName();

    void addObserver(Observer observer);

    void removeObserver(Observer observer);

    void notifyObservers(Movie movie) throws InterruptedException;

    void addMovie(Movie movie) throws InterruptedException;

    void viewMovieList();

    void viewUserList();
}
