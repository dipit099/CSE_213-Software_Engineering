import java.util.ArrayList;
import java.util.List;

class Genre implements Subject {
    private String genreName;
    private List<Observer> observerList;
    private List<Movie> movieList;

    Genre(String genreName) {
        this.genreName = genreName;
        observerList = new ArrayList<>();
        movieList = new ArrayList<>();
        // System.out.println("Created Genre: " + genreName);
    }

    @Override
    public String getName() {
        return genreName;
    }

    @Override
    public void addObserver(Observer observer) {
        observerList.add(observer);

    }

    @Override
    public void removeObserver(Observer observer) {
        observerList.remove(observer);
    }

    @Override
    public void addMovie(Movie movie) throws InterruptedException {
        movie.setGenre(genreName);

        Thread thread = new Thread(() -> {
            try {
                notifyObservers(movie);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });
        thread.start();
        System.out.println();
        System.out.println("Uploading New Movie: " + movie.getMovieName() + " (" + movie.getGenre()
                + ") to the server >>>>>>>>>>>>");
        for (int i = 0; i <= 100; i = i + 25) {
            System.out.println("Progress - " + i + "% out of 100%");
        }
        movieList.add(movie);
        // System.out.println();
        System.out.println(
                "Movie: " + movie.getMovieName() + " Uploaded Successfully <<<<<<<<<<<<");
        System.out.println();
        Thread.sleep(3000);

    }

    @Override
    public void notifyObservers(Movie movie) throws InterruptedException {
        // System.out.println("Notifying Observers");
        // System.out.println("size ------------------------- " + observerList.size());
        for (Observer observer : observerList) {
            // System.out.println("Notifying " + observer);
            observer.notifyUser(movie);
        }

    }

    @Override
    public void viewMovieList() {
        System.out.println("Printing Movie List of Genre: " + genreName);

        for (Movie movie : movieList) {
            System.out.println("Movie Name: " + movie.getMovieName() + " Genre: " + movie.getGenre());
        }
        System.out.println("Done");
    }

    @Override
    public void viewUserList() {
        System.out.println("Printing User List of Genre: " + genreName);
        for (Observer observer : observerList) {
            System.out.println("User : " + observer.getUserName());
        }
        System.out.println("Done");
    }
}