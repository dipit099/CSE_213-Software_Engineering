/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 63.333333333333336, "KoPercent": 36.666666666666664};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6333333333333333, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.46, 500, 1500, "Home/home-43"], "isController": false}, {"data": [0.72, 500, 1500, "Home/submit/firefox-desktop/newtab/1/3abf3449-ba0a-4d83-b0d2-7dd5fbdbcdf8-44"], "isController": false}, {"data": [0.82, 500, 1500, "Home/submit/firefox-desktop/pageload/1/2e80e71d-c1e7-44d9-b8c3-c1e43d4d390c-36"], "isController": false}, {"data": [0.9, 500, 1500, "Home/submit/firefox-desktop/newtab/1/9617c341-d613-4c08-a48e-043e20207dca-38"], "isController": false}, {"data": [0.66, 500, 1500, "Home/submit/firefox-desktop/newtab/1/7f3ffe0f-89e1-4862-b962-9a84bec320f5-42"], "isController": false}, {"data": [0.62, 500, 1500, "Home/submit/firefox-desktop/baseline/1/8fe77efb-c6fd-4882-90af-92c625d91a40-39"], "isController": false}, {"data": [0.64, 500, 1500, "Home/submit/firefox-desktop/baseline/1/300a5b61-86bb-4ffe-825e-254f002f424b-41"], "isController": false}, {"data": [0.58, 500, 1500, "Home/submit/firefox-desktop/use-counters/1/618f7cc1-5566-45dc-ad01-705fadf90e13-37"], "isController": false}, {"data": [0.72, 500, 1500, "Home/submit/firefox-desktop/newtab/1/764700ee-7fab-4b27-9b38-e055b9bc623d-40"], "isController": false}, {"data": [0.0, 500, 1500, "Home/submit/firefox-desktop/newtab/1/661b0ae1-2a33-4ead-b192-f94d379a04d8-33"], "isController": false}, {"data": [0.74, 500, 1500, "Home/submit/firefox-desktop/newtab/1/b85f6dd7-9070-476a-ac6c-0849bed3fa42-34"], "isController": false}, {"data": [0.74, 500, 1500, "Home/submit/firefox-desktop/events/1/e97ea17f-70be-4bb2-b62c-63574b73eeb1-35"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 600, 220, 36.666666666666664, 295.2816666666666, 139, 754, 289.0, 340.79999999999995, 378.89999999999986, 429.98, 5.908710423949972, 7.964872408784283, 14.371707124919986], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home/home-43", 50, 27, 54.0, 309.62000000000006, 139, 754, 308.5, 388.7, 546.0499999999986, 754.0, 0.5088126348353482, 3.7251643782818413, 0.22459307709529042], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/3abf3449-ba0a-4d83-b0d2-7dd5fbdbcdf8-44", 50, 14, 28.0, 285.04, 237, 321, 288.5, 308.9, 317.25, 321.0, 0.5080732844905549, 0.4117874430957921, 1.3694162746034488], "isController": false}, {"data": ["Home/submit/firefox-desktop/pageload/1/2e80e71d-c1e7-44d9-b8c3-c1e43d4d390c-36", 50, 9, 18.0, 279.55999999999983, 243, 319, 278.5, 315.9, 317.9, 319.0, 0.5085797402174687, 0.41084700459247503, 0.7961458237974632], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/9617c341-d613-4c08-a48e-043e20207dca-38", 50, 5, 10.0, 276.12, 237, 328, 274.5, 304.4, 318.79999999999995, 328.0, 0.508440105755542, 0.4058384812894041, 0.7447853111653447], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/7f3ffe0f-89e1-4862-b962-9a84bec320f5-42", 50, 17, 34.0, 290.26000000000005, 250, 327, 290.0, 321.6, 327.0, 327.0, 0.508450446419492, 0.4064624369521447, 1.5362750793182698], "isController": false}, {"data": ["Home/submit/firefox-desktop/baseline/1/8fe77efb-c6fd-4882-90af-92c625d91a40-39", 50, 19, 38.0, 288.70000000000005, 245, 360, 287.0, 321.7, 329.79999999999995, 360.0, 0.5084762999196607, 0.41157779878067385, 1.1877688568435825], "isController": false}, {"data": ["Home/submit/firefox-desktop/baseline/1/300a5b61-86bb-4ffe-825e-254f002f424b-41", 50, 18, 36.0, 290.97999999999996, 234, 439, 290.5, 319.9, 334.6499999999999, 439.0, 0.5083987473054866, 0.4121008752084435, 1.210425923760524], "isController": false}, {"data": ["Home/submit/firefox-desktop/use-counters/1/618f7cc1-5566-45dc-ad01-705fadf90e13-37", 50, 21, 42.0, 290.34, 239, 330, 293.5, 320.8, 326.79999999999995, 330.0, 0.508217883170873, 0.40547250604779284, 1.0948521975341268], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/764700ee-7fab-4b27-9b38-e055b9bc623d-40", 50, 14, 28.0, 287.20000000000005, 238, 344, 286.5, 314.8, 333.15, 344.0, 0.5084452760349404, 0.4089409466234149, 1.537749042851768], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/661b0ae1-2a33-4ead-b192-f94d379a04d8-33", 50, 50, 100.0, 373.56, 303, 455, 369.5, 425.9, 435.84999999999997, 455.0, 0.5081404093579138, 0.41297325339437796, 1.499609684648062], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/b85f6dd7-9070-476a-ac6c-0849bed3fa42-34", 50, 13, 26.0, 286.32000000000005, 243, 370, 282.5, 328.8, 341.4, 370.0, 0.5087142755400001, 0.407527826670872, 1.5211749137729302], "isController": false}, {"data": ["Home/submit/firefox-desktop/events/1/e97ea17f-70be-4bb2-b62c-63574b73eeb1-35", 50, 13, 26.0, 285.68, 230, 343, 286.5, 315.3, 329.34999999999997, 343.0, 0.5085900865620328, 0.4082329450671847, 2.116807567311898], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 304 milliseconds, but should not have lasted longer than 300 milliseconds.", 5, 2.272727272727273, 0.8333333333333334], "isController": false}, {"data": ["The operation lasted too long: It took 325 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 754 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 423 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 398 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 408 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 377 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 443 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 336 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 350 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 303 milliseconds, but should not have lasted longer than 300 milliseconds.", 6, 2.727272727272727, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 330 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 309 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 428 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 399 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 439 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 335 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 361 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 314 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 397 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 300 milliseconds.", 7, 3.1818181818181817, 1.1666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 406 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 316 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 394 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 320 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 313 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 410 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 727 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 348 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 455 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 362 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 342 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 416 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 345 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 326 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 310 milliseconds, but should not have lasted longer than 300 milliseconds.", 8, 3.6363636363636362, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 329 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 355 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 349 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 430 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 300 milliseconds.", 8, 3.6363636363636362, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 332 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 339 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 426 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 374 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 425 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 390 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, 4.545454545454546, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 375 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 301 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, 4.545454545454546, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 322 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 415 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 396 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 343 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 337 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 376 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 414 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 370 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 344 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 369 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 300 milliseconds.", 5, 2.272727272727273, 0.8333333333333334], "isController": false}, {"data": ["The operation lasted too long: It took 341 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 389 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 386 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, 1.8181818181818181, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 9, 4.090909090909091, 1.5], "isController": false}, {"data": ["The operation lasted too long: It took 360 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 300 milliseconds.", 6, 2.727272727272727, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 366 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 318 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 347 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, 0.9090909090909091, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 300 milliseconds.", 9, 4.090909090909091, 1.5], "isController": false}, {"data": ["The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, 4.545454545454546, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 379 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, 0.45454545454545453, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 305 milliseconds, but should not have lasted longer than 300 milliseconds.", 9, 4.090909090909091, 1.5], "isController": false}, {"data": ["The operation lasted too long: It took 331 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, 1.3636363636363635, 0.5], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 600, 220, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, "The operation lasted too long: It took 301 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, "The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 300 milliseconds.", 10, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 9, "The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 300 milliseconds.", 9], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Home/home-43", 50, 27, "The operation lasted too long: It took 349 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 374 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 376 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/3abf3449-ba0a-4d83-b0d2-7dd5fbdbcdf8-44", 50, 14, "The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, "The operation lasted too long: It took 305 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/pageload/1/2e80e71d-c1e7-44d9-b8c3-c1e43d4d390c-36", 50, 9, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 316 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 310 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/9617c341-d613-4c08-a48e-043e20207dca-38", 50, 5, "The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 305 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/7f3ffe0f-89e1-4862-b962-9a84bec320f5-42", 50, 17, "The operation lasted too long: It took 301 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 303 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/baseline/1/8fe77efb-c6fd-4882-90af-92c625d91a40-39", 50, 19, "The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 305 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/baseline/1/300a5b61-86bb-4ffe-825e-254f002f424b-41", 50, 18, "The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 310 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/use-counters/1/618f7cc1-5566-45dc-ad01-705fadf90e13-37", 50, 21, "The operation lasted too long: It took 304 milliseconds, but should not have lasted longer than 300 milliseconds.", 4, "The operation lasted too long: It took 310 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 300 milliseconds.", 2], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/764700ee-7fab-4b27-9b38-e055b9bc623d-40", 50, 14, "The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 337 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 303 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/661b0ae1-2a33-4ead-b192-f94d379a04d8-33", 50, 50, "The operation lasted too long: It took 406 milliseconds, but should not have lasted longer than 300 milliseconds.", 3, "The operation lasted too long: It took 425 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 337 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 410 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 300 milliseconds.", 2], "isController": false}, {"data": ["Home/submit/firefox-desktop/newtab/1/b85f6dd7-9070-476a-ac6c-0849bed3fa42-34", 50, 13, "The operation lasted too long: It took 370 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 348 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 336 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}, {"data": ["Home/submit/firefox-desktop/events/1/e97ea17f-70be-4bb2-b62c-63574b73eeb1-35", 50, 13, "The operation lasted too long: It took 303 milliseconds, but should not have lasted longer than 300 milliseconds.", 2, "The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 300 milliseconds.", 1, "The operation lasted too long: It took 316 milliseconds, but should not have lasted longer than 300 milliseconds.", 1], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
