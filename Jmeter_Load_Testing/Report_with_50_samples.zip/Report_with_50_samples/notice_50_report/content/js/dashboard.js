/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 25.333333333333332, "KoPercent": 74.66666666666667};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.25333333333333335, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Notice/spocs-52"], "isController": false}, {"data": [0.0, 500, 1500, "Notice/home/download/1306-48"], "isController": false}, {"data": [0.0, 500, 1500, "Notice/home/notice-47"], "isController": false}, {"data": [0.84, 500, 1500, "Notice/favicon.ico-50"], "isController": false}, {"data": [0.68, 500, 1500, "Notice/home/notice-51"], "isController": false}, {"data": [0.0, 500, 1500, "Notice/v1/tiles-49"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 300, 224, 74.66666666666667, 291.34000000000015, 27, 1196, 317.0, 594.2000000000006, 783.9999999999998, 1019.8700000000001, 3.0142271521581865, 322.57528974258497, 1.3280457195462583], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Notice/spocs-52", 50, 50, 100.0, 363.94000000000005, 315, 897, 329.5, 402.8, 408.15, 897.0, 0.5104384666428462, 0.6739382879893829, 0.26020398397223216], "isController": false}, {"data": ["Notice/home/download/1306-48", 50, 50, 100.0, 589.5199999999999, 188, 1196, 601.0, 831.9, 1063.6499999999996, 1196.0, 0.5079494082389394, 319.5874815868339, 0.2569509701833697], "isController": false}, {"data": ["Notice/home/notice-47", 50, 50, 100.0, 251.70000000000002, 135, 402, 246.5, 348.3, 386.49999999999994, 402.0, 0.5091857102122287, 1.7821499857428003, 0.22823851658927044], "isController": false}, {"data": ["Notice/favicon.ico-50", 50, 8, 16.0, 69.15999999999998, 27, 119, 68.0, 108.9, 114.59999999999997, 119.0, 0.5112631266807774, 2.290199181723366, 0.23266466507152572], "isController": false}, {"data": ["Notice/home/notice-51", 50, 16, 32.0, 92.08, 45, 307, 88.5, 125.9, 137.0, 307.0, 0.5114513967737646, 1.7895804244535143, 0.2292540928898027], "isController": false}, {"data": ["Notice/v1/tiles-49", 50, 50, 100.0, 381.64000000000016, 317, 970, 326.0, 399.8, 912.7499999999998, 970.0, 0.5088229906580098, 0.06857184835039586, 0.14062197886349295], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 694 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 818 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 300 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 610 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 208 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 265 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 384 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 1.7857142857142858, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 352 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 188 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 709 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 404 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 523 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 379 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 218 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 260 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 456 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 342 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 354 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 682 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 267 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 277 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 389 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 396 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 553 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 826 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 412 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 299 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 322 milliseconds, but should not have lasted longer than 100 milliseconds.", 7, 3.125, 2.3333333333333335], "isController": false}, {"data": ["The operation lasted too long: It took 386 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 431 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 897 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 399 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 325 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 402 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 290 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 119 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 2.232142857142857, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 381 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 1.7857142857142858, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 220 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 387 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 377 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 391 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 401 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 237 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 785 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 230 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 711 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 2.232142857142857, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 144 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 970 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 149 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 400 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 578 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 888 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 398 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 392 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 1,117 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 247 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 411 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 333 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 124 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 246 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 382 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 3.5714285714285716, 2.6666666666666665], "isController": false}, {"data": ["The operation lasted too long: It took 173 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 227 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 192 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 349 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 179 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 606 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 256 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 757 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 378 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 244 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 596 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 331 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 683 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 162 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 403 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 832 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 549 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 787 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 641 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 395 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 100 milliseconds.", 10, 4.464285714285714, 3.3333333333333335], "isController": false}, {"data": ["The operation lasted too long: It took 554 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 792 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 276 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 393 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 232 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 318 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 2.232142857142857, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 437 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 765 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 242 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 197 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 135 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 293 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 296 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 405 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 383 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 2.232142857142857, 1.6666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 380 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 1,196 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 356 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 376 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 283 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 111 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 350 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 686 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 943 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 608 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 763 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 831 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 336 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 375 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 1,020 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 385 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 1.7857142857142858, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 320 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 0.8928571428571429, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 156 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 272 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 394 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 429 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 301 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 1,007 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 137 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 1.3392857142857142, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 195 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 166 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.44642857142857145, 0.3333333333333333], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 300, 224, "The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 100 milliseconds.", 10, "The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, "The operation lasted too long: It took 322 milliseconds, but should not have lasted longer than 100 milliseconds.", 7, "The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 100 milliseconds.", 5], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Notice/spocs-52", 50, 50, "The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, "The operation lasted too long: It took 322 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, "The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 318 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 385 milliseconds, but should not have lasted longer than 100 milliseconds.", 3], "isController": false}, {"data": ["Notice/home/download/1306-48", 50, 50, "The operation lasted too long: It took 267 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 553 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 757 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/notice-47", 50, 50, "The operation lasted too long: It took 237 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 144 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 336 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 296 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 244 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": ["Notice/favicon.ico-50", 50, 8, "The operation lasted too long: It took 119 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 111 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/notice-51", 50, 16, "The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 137 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": ["Notice/v1/tiles-49", 50, 50, "The operation lasted too long: It took 321 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, "The operation lasted too long: It took 381 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 100 milliseconds.", 3], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
